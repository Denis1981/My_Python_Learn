import json
import os
from jsonschema import validate, ValidationError


current_dir = os.path.dirname(os.path.abspath(__file__))
while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

json_path = os.path.join(current_dir, "project_root", "output", "file_info.json")
schema_path = os.path.join(os.path.dirname(__file__), "schema.json")


with open(json_path, "r", encoding="utf-8") as f:
    data = json.load(f)

with open(schema_path, "r", encoding="utf-8") as f:
    schema = json.load(f)


try:
    validate(instance=data, schema=schema)
    print("✅ JSON соответствует схеме")
except ValidationError as e:
    print("❌ Ошибка валидации JSON:")
    print(e.message)
