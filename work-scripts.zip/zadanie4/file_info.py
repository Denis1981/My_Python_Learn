import os
from datetime import datetime

class FileInfo:
    def __init__(self, path: str):
        self.filename = os.path.basename(path)
        self.full_path = os.path.abspath(path)
        self.size = os.path.getsize(path)
        self.created = datetime.fromtimestamp(os.path.getctime(path)).isoformat()
        self.modified = datetime.fromtimestamp(os.path.getmtime(path)).isoformat()

    def to_dict(self):
        return {
            "filename": self.filename,
            "full_path": self.full_path,
            "size": self.size,
            "created": self.created,
            "modified": self.modified
        }

    @staticmethod
    def from_dict(data):
        obj = FileInfo(data['full_path'])
        obj.filename = data['filename']
        obj.size = data['size']
        obj.created = data['created']
        obj.modified = data['modified']
        return obj
