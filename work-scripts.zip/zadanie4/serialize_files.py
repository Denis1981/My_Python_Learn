import os
import json
from file_info import FileInfo


current_dir = os.path.dirname(os.path.abspath(__file__))
while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

processed_dir = os.path.join(current_dir, "project_root", "data", "processed")
output_path = os.path.join(current_dir, "project_root", "output", "file_info.json")


file_infos = []
for file_name in os.listdir(processed_dir):
    file_path = os.path.join(processed_dir, file_name)
    if os.path.isfile(file_path):
        file_infos.append(FileInfo(file_path).to_dict())


with open(output_path, "w", encoding="utf-8") as f:
    json.dump(file_infos, f, indent=4, ensure_ascii=False)

print(f"Сохранено в: {output_path}")
