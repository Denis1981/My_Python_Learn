import os
import json
from datetime import datetime


current_dir = os.path.dirname(os.path.abspath(__file__))
while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

output_path = os.path.join(current_dir, "project_root", "output", "final_report.json")


report = {
    "generated_at": datetime.now().isoformat(),
    "tasks": [
        {
            "task": "Задание 1: Создание структуры директорий",
            "duration_minutes": 5,
            "problems": [
                "Определение корневой директории проекта work-scripts при запуске из подкаталогов."
            ],
            "solutions": [
                "Использован алгоритм подъёма вверх по дереву директорий до work-scripts с помощью os.path.basename + os.path.dirname."
            ],
            "improvements": [
                "Добавить логирование создания директорий в файл logs/init.log."
            ]
        },
        {
            "task": "Задание 2–3: Обработка текстов и сериализация",
            "duration_minutes": 25,
            "problems": [
                "Файлы в raw могут иметь разные кодировки, ошибки декодирования."
            ],
            "solutions": [
                "Использована библиотека chardet для автоматического определения кодировки."
            ],
            "improvements": [
                "Добавить фильтрацию по расширениям, лог ошибок по каждому файлу."
            ]
        },
        {
            "task": "Задание 4: Классы и JSON Schema",
            "duration_minutes": 15,
            "problems": [
                "Необходимо было создать и валидировать схему вручную, подогнать формат дат."
            ],
            "solutions": [
                "Создан класс FileInfo с методом to_dict, JSON Schema подключена и валидируется через jsonschema."
            ],
            "improvements": [
                "Можно добавить автогенерацию схемы на основе pydantic или jsonschema-generator."
            ]
        },
        {
            "task": "Задание 5: Отчёт и логирование",
            "duration_minutes": 24,
            "problems": [],
            "solutions": [
                "Создан отчёт в формате JSON. Расписаны шаги, решения и улучшения."
            ],
            "improvements": [
                "Добавить автоматический подсчет времени выполнения по логам, интеграцию git-хэшей коммитов."
            ]
        }
    ],
    "general_conclusion": "Все задания успешно выполнены. Основная сложность была в корректной работе с кодировками и структурой проекта. Улучшения включают логирование, автоматизацию и применение Git.",
    "recommended_improvements": [
        "Добавить логирование в каждый этап работы (создание директорий, чтение/запись, ошибки).",
        "Использовать систему контроля версий Git с частыми коммитами и README.",
        "Добавить тайминг выполнения задач через time/performance decorators."
    ]
}

# Сохраняем
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(report, f, ensure_ascii=False, indent=4)

print(f"Итоговый отчёт сохранён в {output_path}")
