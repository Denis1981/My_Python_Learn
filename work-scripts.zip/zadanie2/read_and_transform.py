import os
from datetime import datetime
import chardet

def read_and_transform_files(project_root):
    raw_dir = os.path.join(project_root, "data", "raw")
    processed_dir = os.path.join(project_root, "data", "processed")
    os.makedirs(processed_dir, exist_ok=True)

    data_for_json = []

    for filename in os.listdir(raw_dir):
        raw_path = os.path.join(raw_dir, filename)

        # Определение кодировки
        with open(raw_path, 'rb') as f:
            raw_bytes = f.read()
            encoding_info = chardet.detect(raw_bytes)
            encoding = encoding_info['encoding']

        # Декодирование текста
        try:
            text = raw_bytes.decode(encoding)
        except Exception as e:
            print(f"Ошибка декодирования файла {filename}: {e}")
            continue

        # Трансформация текста
        transformed_text = ''.join(
            char.lower() if char.isupper() else char.upper() for char in text
        )

        # Сохранение
        processed_filename = filename.replace(".txt", "") + "_processed.txt"
        processed_path = os.path.join(processed_dir, processed_filename)

        with open(processed_path, "w", encoding="utf-8") as f_out:
            f_out.write(transformed_text)

        file_size = os.path.getsize(processed_path)
        last_modified = datetime.fromtimestamp(os.path.getmtime(processed_path)).isoformat()

        # Добавление метаданных
        data_for_json.append({
            "filename": processed_filename,
            "original_text": text,
            "transformed_text": transformed_text,
            "file_size_bytes": file_size,
            "last_modified": last_modified
        })

    return data_for_json
