import os
from read_and_transform import read_and_transform_files
from serialize_to_json import save_data_to_json

current_dir = os.path.dirname(os.path.abspath(__file__))
while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

project_root = os.path.join(current_dir, "project_root")


data = read_and_transform_files(project_root)
save_data_to_json(project_root, data)
