import os
import json

def save_data_to_json(project_root, data):
    output_dir = os.path.join(project_root, "output")
    os.makedirs(output_dir, exist_ok=True)

    json_path = os.path.join(output_dir, "processed_data.json")
    with open(json_path, "w", encoding="utf-8") as json_file:
        json.dump(data, json_file, ensure_ascii=False, indent=4)

    print("Сериализация завершена. JSON создан:", json_path)
