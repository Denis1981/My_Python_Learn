import os
from datetime import datetime

current_dir = os.path.dirname(os.path.abspath(__file__))

while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

project_root = os.path.join(current_dir, "project_root")

directories = [
    os.path.join(project_root, "data", "raw"),
    os.path.join(project_root, "data", "processed"),
    os.path.join(project_root, "logs"),
    os.path.join(project_root, "backups"),
    os.path.join(project_root, "output"),
]

log_entries = []

for directory in directories:
    os.makedirs(directory, exist_ok=True)
    log_entries.append(f"{datetime.now()} — создана директория: {directory}")

