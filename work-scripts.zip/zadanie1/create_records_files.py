import os
from datetime import datetime

current_dir = os.path.dirname(os.path.abspath(__file__))

while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

project_root = os.path.join(current_dir, "project_root")

raw_dir = os.path.join(project_root, "data", "raw")

log_entries = []

files = [
    ("file_utf8.txt", "Привет, мир!", "utf-8"),
    ("file_latin1.txt", "Olá, mundo!", "iso-8859-1"),
    ("file_cp1251.txt", "Здравствуйте!", "cp1251"),
]

for filename, content, encoding in files:
    file_path = os.path.join(raw_dir, filename)
    with open(file_path, "w", encoding=encoding) as f:
        f.write(content)
    log_entries.append(f"{datetime.now()} — создан файл: {file_path} с кодировкой: {encoding}")


log_path = os.path.join(project_root, "logs", "setup_log.txt")
with open(log_path, "w", encoding="utf-8") as log_file:
    for entry in log_entries:
        log_file.write(entry + "\n")

print("Проект успешно инициализирован. Логи записаны.")
