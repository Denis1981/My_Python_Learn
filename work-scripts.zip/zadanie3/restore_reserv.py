import os
from zipfile import ZipFile

current_dir = os.path.dirname(os.path.abspath(__file__))

while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

project_root = os.path.join(current_dir, "project_root")

backups_dir = os.path.join(project_root, "backups")

# Поиск последнего архива
backup_files = sorted([
    f for f in os.listdir(backups_dir) if f.startswith("backup_") and f.endswith(".zip")
], reverse=True)

if not backup_files:
    print("❌ Нет архивов для восстановления.")
    exit()

latest_backup = backup_files[0]
backup_path = os.path.join(backups_dir, latest_backup)

with ZipFile(backup_path, 'r') as zipf:
    zipf.extractall(project_root)

print(f"✅ Данные восстановлены из: {latest_backup}")
