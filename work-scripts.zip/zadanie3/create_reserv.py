import os
from datetime import datetime
from zipfile import ZipFile

current_dir = os.path.dirname(os.path.abspath(__file__))

while os.path.basename(current_dir) != "work-scripts":
    current_dir = os.path.dirname(current_dir)

project_root = os.path.join(current_dir, "project_root")

data_dir = os.path.join(project_root, "data")
backups_dir = os.path.join(project_root, "backups")

# Убедимся, что папка для бэкапов существует
os.makedirs(backups_dir, exist_ok=True)

# Имя архива
current_date = datetime.now().strftime("%Y%m%d")
backup_filename = f"backup_{current_date}.zip"
backup_path = os.path.join(backups_dir, backup_filename)

# Архивируем
with ZipFile(backup_path, 'w') as zipf:
    for root, dirs, files in os.walk(data_dir):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, start=project_root)  # сохраняем относительный путь
            zipf.write(file_path, arcname=arcname)

print(f"✅ Резервная копия создана: {backup_path}")
