from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'content']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Введите заголовок'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Введите текст поста'}),
        }

    def clean_title(self):
        title = self.cleaned_data.get('title')
        if not title or len(title.strip()) < 5:
            raise forms.ValidationError("Заголовок должен содержать минимум 5 символов.")
        return title.strip()

    def clean_content(self):
        content = self.cleaned_data.get('content')
        if not content or len(content.strip()) < 20:
            raise forms.ValidationError("Содержание должно быть не менее 20 символов.")
        return content.strip()
