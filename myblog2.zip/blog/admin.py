from django.contrib import admin
from django import forms
from .models import *

class PostAdminForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = '__all__'

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    form = PostAdminForm
    save_as = True
    save_on_top = True
    list_display = ('id', 'title')
    list_display_links = ('id', 'title')
    search_fields = ('title',)
    fields = ('title', 'content')


